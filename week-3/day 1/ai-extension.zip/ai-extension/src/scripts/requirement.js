import { getPrompt } from './prompts.js';

class RequirementUI {
    constructor() {
        this.contextInput  = document.getElementById('reqContext');
        this.domainInput   = document.getElementById('reqDomain');
        this.createButton  = document.getElementById('reqCreate');
        this.resetButton   = document.getElementById('reqReset');
        this.messagesEl    = document.getElementById('reqMessages');
        this.copyButton    = document.getElementById('reqCopy');

        this.selectedModel    = '';
        this.selectedProvider = '';
        this.markdownReady    = false;

        this.initMarkdown();
        this.loadSettings();
        this.bindEvents();
    }

    // ─── Settings ────────────────────────────────────────────────────────────

    loadSettings() {
        chrome.storage.sync.get(
            ['groqApiKey', 'openaiApiKey', 'testleafApiKey', 'selectedModel', 'selectedProvider'],
            (r) => {
                if (r.groqApiKey)     this.groqAPI     = new GroqAPI(r.groqApiKey);
                if (r.openaiApiKey)   this.openaiAPI   = new OpenAIAPI(r.openaiApiKey);
                if (r.testleafApiKey) this.testleafAPI = new TestleafAPI(r.testleafApiKey);
                this.selectedModel    = r.selectedModel    || '';
                this.selectedProvider = r.selectedProvider || '';
            }
        );
        chrome.storage.onChanged.addListener((c) => {
            if (c.groqApiKey)       this.groqAPI     = new GroqAPI(c.groqApiKey.newValue);
            if (c.openaiApiKey)     this.openaiAPI   = new OpenAIAPI(c.openaiApiKey.newValue);
            if (c.testleafApiKey)   this.testleafAPI = new TestleafAPI(c.testleafApiKey.newValue);
            if (c.selectedModel)    this.selectedModel    = c.selectedModel.newValue;
            if (c.selectedProvider) this.selectedProvider = c.selectedProvider.newValue;
        });
    }

    copyResult() {
        const text = this._lastContent || '';
        if (!text) return;
        navigator.clipboard.writeText(text)
            .then(() => {
                this.copyButton.classList.add('copied');
                this.copyButton.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
                setTimeout(() => {
                    this.copyButton.classList.remove('copied');
                    this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
                }, 2000);
            })
            .catch(() => {
                this.copyButton.innerHTML = '<i class="fas fa-times"></i><span>Failed</span>';
                setTimeout(() => { this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>'; }, 2000);
            });
    }

    resolveApi() {
        if (this.selectedProvider === 'groq')   return this.groqAPI;
        if (this.selectedProvider === 'openai') return this.openaiAPI;
        return this.testleafAPI || null;
    }

    // ─── Events ──────────────────────────────────────────────────────────────

    bindEvents() {
        this.createButton.addEventListener('click', () => this.create());

        this.resetButton.addEventListener('click', () => {
            this.contextInput.value = '';
            this.domainInput.value  = '';
            this._lastContent = '';
            this.copyButton.style.display = 'none';
            this.messagesEl.innerHTML = `
                <div class="initial-message">
                    <i class="fas fa-file-lines"></i>
                    <span>Enter a <strong>Requirement Context</strong> and <strong>Domain</strong>, then click <strong>Create Requirement</strong>.</span>
                </div>`;
        });

        this.copyButton.addEventListener('click', () => this.copyResult());

        // Ctrl/Cmd+Enter in textarea submits
        this.contextInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                this.create();
            }
        });
        this.domainInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); this.create(); }
        });
    }

    // ─── Core create ─────────────────────────────────────────────────────────

    async create() {
        const context = this.contextInput.value.trim();
        const domain  = this.domainInput.value.trim();

        if (!context) {
            this.showMsg('<i class="fas fa-circle-exclamation"></i> Please enter a <strong>Requirement Context</strong>.', 'system-message');
            this.contextInput.focus();
            return;
        }
        if (!domain) {
            this.showMsg('<i class="fas fa-circle-exclamation"></i> Please enter a <strong>Domain</strong>.', 'system-message');
            this.domainInput.focus();
            return;
        }

        const apiRef = this.resolveApi();
        if (!apiRef) {
            this.showMsg('<i class="fas fa-gear"></i> No API key found. Configure your provider in the <strong>Settings</strong> tab.', 'system-message');
            return;
        }

        const prompt = getPrompt('REQUIREMENT_GENERATOR', { context, domain });

        // Loading
        this.createButton.disabled = true;
        this.createButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Creating…</span>';
        this.messagesEl.innerHTML = `
            <div class="loading-indicator active">
                <div class="loading-spinner"></div>
                <span class="loading-text">Generating JIRA requirements for <em>${this.escapeHtml(domain)}</em>…</span>
            </div>`;

        try {
            const resp    = await apiRef.sendMessage(prompt, this.selectedModel);
            const content = (resp?.content || resp).trim();

            this.messagesEl.innerHTML = '';
            this._lastContent = content;
            this.copyButton.style.display = 'inline-flex';
            this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
            this.renderResult(content);

        } catch (err) {
            this.messagesEl.innerHTML = '';
            this.showMsg(`<i class="fas fa-circle-exclamation"></i> Error: ${this.escapeHtml(err.message)}`, 'system-message');
        } finally {
            this.createButton.disabled = false;
            this.createButton.innerHTML = '<i class="fas fa-file-lines"></i><span>Create Requirement</span>';
        }
    }

    // ─── Rendering ───────────────────────────────────────────────────────────

    renderResult(content) {
        const wrapper = document.createElement('div');
        wrapper.className = 'assistant-message';

        // Markdown body
        const mdDiv = document.createElement('div');
        mdDiv.className = 'markdown-content';
        mdDiv.innerHTML = this.parseMarkdown(content);
        wrapper.appendChild(mdDiv);

        // Actions bar
        const actions = document.createElement('div');
        actions.className = 'message-actions';

        const copyBtn = document.createElement('button');
        copyBtn.className = 'btn-copy';
        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
        copyBtn.onclick = () => {
            navigator.clipboard.writeText(content)
                .then(() => {
                    copyBtn.classList.add('copied');
                    copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyBtn.classList.remove('copied');
                        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
                    }, 2000);
                })
                .catch(() => {
                    copyBtn.innerHTML = '<i class="fas fa-times"></i> Failed';
                    setTimeout(() => { copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard'; }, 2000);
                });
        };
        actions.appendChild(copyBtn);
        wrapper.appendChild(actions);

        this.messagesEl.appendChild(wrapper);
        this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }

    showMsg(html, cls = '') {
        const div = document.createElement('div');
        div.className = `chat-message${cls ? ' ' + cls : ''}`;
        div.innerHTML = html;
        this.messagesEl.appendChild(div);
        this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }

    escapeHtml(t) {
        return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    initMarkdown() {
        const iv = setInterval(() => {
            if (window.marked) { this.markdownReady = true; clearInterval(iv); }
        }, 100);
    }

    parseMarkdown(content) {
        if (!this.markdownReady) return `<pre>${this.escapeHtml(content)}</pre>`;
        try {
            return window.marked.parse(
                content.replace(/```(\w*)/g, '\n```$1\n')
                       .replace(/```\s*$/g, '\n```\n')
                       .replace(/\n{3,}/g, '\n\n')
            );
        } catch { return `<pre>${this.escapeHtml(content)}</pre>`; }
    }
}

try {
    new RequirementUI();
} catch (e) {
    console.error('[RequirementUI] init error:', e);
}
