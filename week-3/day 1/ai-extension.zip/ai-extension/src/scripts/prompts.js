/**
 * Collection of default prompts for different use cases (ICE POT Format)
 */
export const DEFAULT_PROMPTS = {

  // ---------------------------------------------------------------------------
  // Selenium Java Page Object (no test code)
  // ---------------------------------------------------------------------------
  SELENIUM_JAVA_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Selenium Java Page Object Class (no test code).
    - Add JavaDoc for methods & class.
    - Use Selenium 2.30+ compatible imports.
    - Use meaningful method names.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`java
    package com.testleaf.pages;
    public class ComponentPage {
        // Add methods as per the DOM
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure.

    Output Format:
    - A single Java class inside a \`\`\`java\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  // ---------------------------------------------------------------------------
  // Cucumber Feature File Only
  // ---------------------------------------------------------------------------
  CUCUMBER_ONLY: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps
    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully
    Examples:
      | username   | password   |
      | "testuser" | "testpass" |
    \`\`\`

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  // ---------------------------------------------------------------------------
  // Cucumber + Selenium Java Step Definitions
  // ---------------------------------------------------------------------------
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: `
    Instructions:
    - Generate BOTH a Cucumber .feature file AND a Java step definition class.
    - Do NOT include Page Object code.
    - Step defs must include WebDriver setup, explicit waits, and actual Selenium code.
    - Use Scenario Outline with Examples table (South India realistic data).

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + Java code in \`\`\`java\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `,

  // ---------------------------------------------------------------------------
  // Playwright TypeScript POM (no test)
  // ---------------------------------------------------------------------------
  PLAYWRIGHT_TYPESCRIPT_POM: `
    Instructions:
    - Generate ONLY a Playwright TypeScript Page Object Model class (no test code).
    - Add JSDoc comments for all methods and the class.
    - Use Playwright locators (page.locator(), page.getByRole(), etc.).
    - Make all methods async and use async/await syntax.
    - Use meaningful method names following camelCase convention.
    - Do NOT include test code or fixture setup.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Output Format:
    - A single TypeScript class inside a \`\`\`typescript\`\`\` block.

    Tone:
    - Modern, async-first, enterprise-ready for Playwright.
  `,

  // ---------------------------------------------------------------------------
  // Playwright TypeScript Test Spec Only
  // ---------------------------------------------------------------------------
  PLAYWRIGHT_TYPESCRIPT_SPEC: `
    Instructions:
    - Generate ONLY a Playwright TypeScript test specification file (no Page Object).
    - Use @playwright/test framework with test() and expect().
    - Include test.beforeEach() and test.afterEach() hooks.
    - Use async/await syntax throughout.
    - Use South India realistic dataset (names, addresses, pin codes).
    - Use dropdown values only from provided DOM.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Output Format:
    - TypeScript test code in a \`\`\`typescript\`\`\` block.

    Tone:
    - Clear, async-first, executable immediately.
  `,

  // ---------------------------------------------------------------------------
  // Playwright TypeScript POM + Spec Combined
  // ---------------------------------------------------------------------------
  PLAYWRIGHT_TYPESCRIPT_POM_AND_SPEC: `
    Instructions:
    - Generate BOTH a Playwright TypeScript Page Object Model class AND a test spec.
    - Page Object: async methods, Playwright locators, JSDoc comments.
    - Test Spec: import and use the Page Object, create realistic test scenarios.
    - Use South India realistic dataset for test data.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Output Format:
    - First \`\`\`typescript\`\`\` block: Page Object Model code.
    - Second \`\`\`typescript\`\`\` block: Test specification code.

    Tone:
    - Professional, modular, production-ready architecture.
  `,

  // ---------------------------------------------------------------------------
  // Test Case Generator
  // ---------------------------------------------------------------------------
  TEST_CASE_GENERATOR: `
    Instructions:
    - Generate detailed manual test cases for the given feature and domain.
    - Organise cases by type: Positive, Negative, Edge Case, Boundary (only include types requested).
    - Each test case must include:
        TC ID           | Unique identifier (TC-001, TC-002 ...)
        Title           | Short descriptive title
        Preconditions   | What must be true before running the test
        Test Steps      | Numbered, atomic steps
        Test Data       | Realistic sample data relevant to the domain
        Expected Result | Clear, verifiable outcome
        Priority        | High / Medium / Low
    - Use realistic test data appropriate for the domain.
    - Do NOT include code or implementation details.

    Context:
    Feature  : \${feature}
    Domain   : \${domain}
    Coverage : \${coverage}

    Example output format:
    ---
    ## TC-001: Successful login with valid credentials
    **Type:** Positive
    **Priority:** High
    **Preconditions:** User account exists and is active
    **Test Steps:**
    1. Navigate to the login page
    2. Enter a valid username
    3. Enter the correct password
    4. Click the Login button
    **Test Data:** username: john.doe@example.com | password: Test@1234
    **Expected Result:** User is redirected to the dashboard and a welcome message is displayed.
    ---

    Persona:
    - Audience: Manual QA testers and test leads reviewing test coverage.

    Output Format:
    - One test case per markdown section separated by ---.

    Tone:
    - Precise, professional, unambiguous.
  `,

  // ---------------------------------------------------------------------------
  // Test Coverage Analyser
  // ---------------------------------------------------------------------------
  TEST_COVERAGE_ANALYSIS: `
    Instructions:
    - You are a senior QA analyst. Analyse the test cases below for the given feature and domain.
    - Return a structured coverage report in the EXACT JSON format shown in the Example.
    - Score each dimension out of 100. The "overall" score is the weighted average.
    - "gaps" must be a flat list of short, actionable gap descriptions (max 10 items).
    - Do NOT wrap the JSON in a code block. Return raw JSON only.

    Context:
    Feature   : \${feature}
    Domain    : \${domain}
    Test Cases:
    \${testCases}

    Example (return ONLY JSON matching this shape):
    {
      "overall": 62,
      "dimensions": {
        "Positive / Happy Path": 85,
        "Negative / Error Handling": 55,
        "Edge Cases": 40,
        "Boundary Values": 30,
        "Security": 20,
        "Performance / Load": 10,
        "Accessibility": 0
      },
      "gaps": [
        "No test for expired session / token",
        "Missing boundary test for maximum input length",
        "No test covering concurrent user actions",
        "SQL injection and XSS inputs not tested"
      ],
      "summary": "Coverage is moderate. Core happy-path and basic negative scenarios are covered but security, boundary, and concurrency scenarios are missing."
    }
  `,

  // ---------------------------------------------------------------------------
  // Gap-targeted test case regeneration
  // ---------------------------------------------------------------------------
  TEST_GAP_REGENERATION: `
    Instructions:
    - You are a senior QA engineer. Generate NEW test cases that specifically address the gaps listed below.
    - Do NOT repeat test cases that already exist.
    - Each new test case must follow the same markdown format as the existing ones.
    - Start TC IDs from \${startId}.
    - Use realistic test data appropriate for the domain.

    Context:
    Feature : \${feature}
    Domain  : \${domain}
    Gaps to cover:
    \${gaps}

    Output Format:
    - One test case per markdown section separated by ---, using this template:
    ---
    ## TC-XXX: <Title>
    **Type:** <type>
    **Priority:** High / Medium / Low
    **Preconditions:** <preconditions>
    **Test Steps:**
    1. <step>
    **Test Data:** <data>
    **Expected Result:** <expected>
    ---

    Tone:
    - Precise, professional, directly addressing each gap.
  `,

  // ---------------------------------------------------------------------------
  // Karate Cucumber Feature File (UI automation using Karate DSL)
  // ---------------------------------------------------------------------------
  KARATE_CUCUMBER: `
    Instructions:
    - Generate a Karate DSL feature file for UI automation based on the provided DOM.
    - Use Karate's built-in UI automation commands (driver, click, input, submit, etc.).
    - Include a Background section to configure the driver and base URL.
    - Use Scenario Outline with Examples table for data-driven tests.
    - Use locator strategies compatible with Karate: CSS selectors preferred.
    - Do NOT generate separate step definition files (Karate has no step defs).
    - Use realistic test data appropriate to the page context.
    - Use South India realistic dataset where applicable.
    - Add assertions using Karate's match keyword.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: User Login

      Background:
        * configure driver = { type: 'chrome', headless: false }
        * def baseUrl = '<pageUrl>'

      Scenario Outline: Successful login with valid credentials
        Given driver baseUrl
        And input('#username', '<username>')
        And input('#password', '<password>')
        When click('button[type=submit]')
        Then waitForUrl(baseUrl + '/dashboard')
        And match driver.title contains 'Dashboard'

      Examples:
        | username          | password   |
        | ravi@example.com  | Pass@123   |
        | priya@example.com | Test@456   |

      Scenario: Login with invalid credentials
        Given driver baseUrl
        And input('#username', 'wrong@example.com')
        And input('#password', 'wrongpass')
        When click('button[type=submit]')
        Then waitFor('.error-message')
        And match text('.error-message') contains 'Invalid'
    \`\`\`

    Output Format:
    - A single \`\`\`gherkin\`\`\` code block.

    Tone:
    - Clean, idiomatic Karate DSL, ready to run with karate-ui.
  `,

  // ---------------------------------------------------------------------------
  // Requirement Generator (JIRA format)
  // ---------------------------------------------------------------------------
  REQUIREMENT_GENERATOR: `
    Instructions:
    - You are a senior Business Analyst. Generate a complete set of JIRA-ready requirements from the context provided.
    - Output MUST follow this exact structure:
        1. One Epic (title + one-sentence description)
        2. 3-6 User Stories under the Epic, each containing:
           - Story title
           - User Story sentence (As a / I want / So that)
           - Acceptance Criteria (3-5 Given/When/Then bullet points, prefixed with "- [ ]")
           - Priority: High / Medium / Low
           - Story Points estimate (1, 2, 3, 5, 8)
           - Suggested Labels (comma-separated, domain-relevant)
    - Add a Sub-tasks section under each story where applicable.
    - Use realistic, domain-appropriate language.
    - Do NOT include code, technical implementation details, or prose outside the template.

    Context:
    Requirement Context : \${context}
    Domain              : \${domain}

    Output format (follow this template exactly):
    ---
    ## Epic: <Epic Title>
    **Description:** <One-sentence epic description>

    ---
    ### Story 1: <Story Title>
    **As a** <type of user>, **I want** <capability>, **so that** <business value>.

    **Acceptance Criteria:**
    - [ ] Given <precondition>, When <action>, Then <expected outcome>
    - [ ] Given <precondition>, When <action>, Then <expected outcome>
    - [ ] Given <precondition>, When <action>, Then <expected outcome>

    **Priority:** High | Medium | Low
    **Story Points:** X
    **Labels:** label-one, label-two

    **Sub-tasks:**
    - [ ] <sub-task description>
    - [ ] <sub-task description>
    ---
    (repeat for each story)

    Tone:
    - Precise, business-focused, immediately usable in JIRA.
  `
};

/**
 * Fill template variables in a prompt string.
 * Variables in the prompts are written as \${varName} to prevent JS interpolation;
 * this function substitutes them at call time.
 */
export function getPrompt(promptKey, variables = {}) {
  let prompt = DEFAULT_PROMPTS[promptKey];
  if (!prompt) {
    throw new Error('Prompt not found: ' + promptKey);
  }
  Object.entries(variables).forEach(([k, v]) => {
    const regex = new RegExp('\\\$\{' + k + '\}', 'g');
    prompt = prompt.replace(regex, v);
  });
  return prompt.trim();
}

export const CODE_GENERATOR_TYPES = {
  SELENIUM_JAVA_PAGE_ONLY:            'Selenium-Java-Page-Only',
  CUCUMBER_ONLY:                      'Cucumber-Only',
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS:  'Cucumber-With-Selenium-Java-Steps',
  PLAYWRIGHT_TYPESCRIPT_POM:          'Playwright-TypeScript-POM',
  PLAYWRIGHT_TYPESCRIPT_SPEC:         'Playwright-TypeScript-Spec',
  PLAYWRIGHT_TYPESCRIPT_POM_AND_SPEC: 'Playwright-TypeScript-POM-And-Spec',
  TEST_CASE_GENERATOR:                'Test-Case-Generator',
  TEST_COVERAGE_ANALYSIS:             'Test-Coverage-Analysis',
  TEST_GAP_REGENERATION:              'Test-Gap-Regeneration',
  REQUIREMENT_GENERATOR:              'Requirement-Generator',
};
