import { getPrompt } from './prompts.js';

// SVG ring circumference for r=34
const CIRCUMFERENCE = 2 * Math.PI * 34; // ≈ 213.6

class CoverageUI {
    constructor() {
        this.analyzeBtn      = document.getElementById('covAnalyze');
        this.regenBtn        = document.getElementById('covRegenerate');
        this.scoreValue      = document.getElementById('covScoreValue');
        this.ringFill        = document.getElementById('covRingFill');
        this.summaryText     = document.getElementById('covSummaryText');
        this.gapsSection     = document.getElementById('covGapsSection');
        this.gapsList        = document.getElementById('covGapsList');
        this.resultContainer = document.getElementById('covResultContainer');
        this.messagesEl      = document.getElementById('covMessages');
        this.emptyState      = document.getElementById('covEmptyState');

        // ring setup
        this.ringFill.style.strokeDasharray  = CIRCUMFERENCE;
        this.ringFill.style.strokeDashoffset = CIRCUMFERENCE;

        this.analysisResult = null; // last parsed coverage JSON
        this.markdownReady  = false;
        this.selectedModel    = '';
        this.selectedProvider = '';

        this.initMarkdown();
        this.loadSettings();
        this.bindEvents();
    }

    // ─── Settings ────────────────────────────────────────────────────────────

    loadSettings() {
        chrome.storage.sync.get(
            ['groqApiKey', 'openaiApiKey', 'testleafApiKey', 'selectedModel', 'selectedProvider'],
            (r) => {
                if (r.groqApiKey)     this.groqAPI     = new GroqAPI(r.groqApiKey);
                if (r.openaiApiKey)   this.openaiAPI   = new OpenAIAPI(r.openaiApiKey);
                if (r.testleafApiKey) this.testleafAPI = new TestleafAPI(r.testleafApiKey);
                this.selectedModel    = r.selectedModel    || '';
                this.selectedProvider = r.selectedProvider || '';
            }
        );
        chrome.storage.onChanged.addListener((c) => {
            if (c.groqApiKey)       this.groqAPI     = new GroqAPI(c.groqApiKey.newValue);
            if (c.openaiApiKey)     this.openaiAPI   = new OpenAIAPI(c.openaiApiKey.newValue);
            if (c.testleafApiKey)   this.testleafAPI = new TestleafAPI(c.testleafApiKey.newValue);
            if (c.selectedModel)    this.selectedModel    = c.selectedModel.newValue;
            if (c.selectedProvider) this.selectedProvider = c.selectedProvider.newValue;
        });
    }

    resolveApi() {
        if (this.selectedProvider === 'groq')   return this.groqAPI;
        if (this.selectedProvider === 'openai') return this.openaiAPI;
        return this.testleafAPI || null;
    }

    // ─── Events ──────────────────────────────────────────────────────────────

    bindEvents() {
        this.analyzeBtn.addEventListener('click', () => this.analyze());
        this.regenBtn.addEventListener('click',   () => this.regenerate());

        // When new test cases are generated, reset the coverage panel
        document.addEventListener('tc:generated', () => this.resetPanel());
        document.addEventListener('tc:cleared',   () => this.resetPanel(true));
    }

    resetPanel(full = false) {
        this.setScore(null);
        this.gapsSection.style.display     = 'none';
        this.resultContainer.style.display = 'none';
        this.regenBtn.style.display        = 'none';
        this.gapsList.innerHTML            = '';
        this.messagesEl.innerHTML          = '';
        this.analysisResult                = null;

        if (full) {
            this.summaryText.textContent = 'Generate test cases first, then analyze coverage.';
            this.emptyState.style.display = '';
            this.analyzeBtn.style.display = 'none';
        } else {
            this.summaryText.textContent = 'Test cases ready. Click Analyze Coverage.';
            this.emptyState.style.display = 'none';
            this.analyzeBtn.style.display = '';
        }
    }

    // ─── Analyze ─────────────────────────────────────────────────────────────

    async analyze() {
        const state = window._tcState;
        if (!state) {
            this.summaryText.textContent = 'No test cases found. Generate test cases first.';
            return;
        }

        const apiRef = this.resolveApi();
        if (!apiRef) {
            this.summaryText.textContent = 'No API key configured. Go to Settings.';
            return;
        }

        // Loading state
        this.analyzeBtn.disabled = true;
        this.analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Analyzing…</span>';
        this.summaryText.textContent = 'Analyzing your test cases…';
        this.setScore(null);
        this.gapsSection.style.display = 'none';
        this.regenBtn.style.display    = 'none';

        try {
            const prompt = getPrompt('TEST_COVERAGE_ANALYSIS', {
                feature:   state.feature,
                domain:    state.domain,
                testCases: state.content,
            });

            const resp    = await apiRef.sendMessage(prompt, this.selectedModel);
            const raw     = (resp?.content || resp).trim();
            const parsed  = this.parseJson(raw);

            if (!parsed) {
                this.summaryText.textContent = 'Could not parse coverage analysis. Try again.';
                return;
            }

            this.analysisResult = parsed;
            this.renderAnalysis(parsed);

        } catch (err) {
            this.summaryText.textContent = `Error: ${err.message}`;
        } finally {
            this.analyzeBtn.disabled = false;
            this.analyzeBtn.innerHTML = '<i class="fas fa-chart-pie"></i><span>Re-analyze</span>';
        }
    }

    renderAnalysis(data) {
        // Score ring
        this.setScore(data.overall);

        // Summary
        this.summaryText.textContent = data.summary || '';

        // Dimension bars
        this.gapsList.innerHTML = '';

        if (data.dimensions) {
            Object.entries(data.dimensions).forEach(([dim, score]) => {
                const li = document.createElement('li');
                li.className = 'cov-dim-item';
                li.innerHTML = `
                    <div class="cov-dim-header">
                        <span class="cov-dim-name">${this.escapeHtml(dim)}</span>
                        <span class="cov-dim-score">${score}%</span>
                    </div>
                    <div class="cov-dim-bar">
                        <div class="cov-dim-fill" style="width:${score}%;background:${this.scoreColor(score)}"></div>
                    </div>`;
                this.gapsList.appendChild(li);
            });
        }

        if (data.gaps && data.gaps.length) {
            const divider = document.createElement('li');
            divider.className = 'cov-gaps-divider';
            divider.textContent = 'Gaps to address:';
            this.gapsList.appendChild(divider);

            data.gaps.forEach(gap => {
                const li = document.createElement('li');
                li.className = 'cov-gap-item';
                li.innerHTML = `<i class="fas fa-triangle-exclamation"></i> ${this.escapeHtml(gap)}`;
                this.gapsList.appendChild(li);
            });
        }

        this.gapsSection.style.display = '';
        if (data.gaps && data.gaps.length) {
            this.regenBtn.style.display = '';
        }
    }

    // ─── Regenerate ──────────────────────────────────────────────────────────

    async regenerate() {
        const state = window._tcState;
        if (!state || !this.analysisResult) return;

        const apiRef = this.resolveApi();
        if (!apiRef) return;

        // Estimate next TC ID from existing content
        const existingIds = (state.content.match(/TC-(\d+)/g) || [])
            .map(id => parseInt(id.replace('TC-', ''), 10))
            .filter(n => !isNaN(n));
        const maxId   = existingIds.length ? Math.max(...existingIds) : 0;
        const startId = String(maxId + 1).padStart(3, '0');
        const nextId  = String(maxId + 2).padStart(3, '0');

        const gaps = (this.analysisResult.gaps || []).join('\n- ');

        // Loading
        this.regenBtn.disabled = true;
        this.regenBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Regenerating…</span>';
        this.resultContainer.style.display = '';
        this.messagesEl.innerHTML = `
            <div class="loading-indicator active">
                <div class="loading-spinner"></div>
                <span class="loading-text">Generating gap-targeted test cases…</span>
            </div>`;

        try {
            const prompt = getPrompt('TEST_GAP_REGENERATION', {
                feature: state.feature,
                domain:  state.domain,
                gaps:    `- ${gaps}`,
                startId,
                nextId,
            });

            const resp    = await apiRef.sendMessage(prompt, this.selectedModel);
            const content = (resp?.content || resp).trim();

            // Append to shared test case state so subsequent analyses include new cases
            window._tcState.content += '\n\n' + content;

            this.messagesEl.innerHTML = '';
            this.renderRegenResult(content, resp);

        } catch (err) {
            this.messagesEl.innerHTML = '';
            const errDiv = document.createElement('div');
            errDiv.className = 'chat-message system-message';
            errDiv.textContent = `Error: ${err.message}`;
            this.messagesEl.appendChild(errDiv);
        } finally {
            this.regenBtn.disabled = false;
            this.regenBtn.innerHTML = '<i class="fas fa-rotate"></i><span>Regenerate for Gaps</span>';
        }
    }

    renderRegenResult(content, resp) {
        const container = document.createElement('div');
        container.className = 'assistant-message';

        const mdDiv = document.createElement('div');
        mdDiv.className = 'markdown-content';
        mdDiv.innerHTML = this.parseMarkdown(content);
        container.appendChild(mdDiv);

        const actions = document.createElement('div');
        actions.className = 'message-actions';
        actions.style.cssText = 'padding:4px 8px;background:var(--color-darker-bg);';

        const copyBtn = document.createElement('button');
        copyBtn.className = 'btn-copy';
        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
        copyBtn.onclick = () => {
            navigator.clipboard.writeText(content).then(() => {
                copyBtn.classList.add('copied');
                copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                setTimeout(() => {
                    copyBtn.classList.remove('copied');
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
                }, 2000);
            }).catch(() => {
                copyBtn.innerHTML = '<i class="fas fa-times"></i> Failed';
                setTimeout(() => { copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard'; }, 2000);
            });
        };
        actions.appendChild(copyBtn);

        const reAnalyzeBtn = document.createElement('button');
        reAnalyzeBtn.innerHTML = '<i class="fas fa-chart-pie"></i> Re-analyze Coverage';
        reAnalyzeBtn.style.marginLeft = '8px';
        reAnalyzeBtn.onclick = () => this.analyze();
        actions.appendChild(reAnalyzeBtn);

        container.appendChild(actions);
        this.messagesEl.appendChild(container);
        this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
    }

    // ─── Score ring ──────────────────────────────────────────────────────────

    setScore(score) {
        if (score === null || score === undefined) {
            this.scoreValue.textContent = '—';
            this.ringFill.style.strokeDashoffset = CIRCUMFERENCE;
            this.ringFill.style.stroke = 'var(--color-accent)';
            return;
        }
        const pct    = Math.max(0, Math.min(100, score));
        const offset = CIRCUMFERENCE - (pct / 100) * CIRCUMFERENCE;
        this.scoreValue.textContent          = `${pct}%`;
        this.ringFill.style.strokeDashoffset = offset;
        this.ringFill.style.stroke           = this.scoreColor(pct);
    }

    scoreColor(pct) {
        if (pct >= 75) return '#4caf50';
        if (pct >= 50) return '#ff9800';
        return '#f44336';
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    parseJson(raw) {
        try {
            // Strip any accidental markdown fencing
            const clean = raw.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
            return JSON.parse(clean);
        } catch {
            // Try to find JSON object inside the text
            const match = raw.match(/\{[\s\S]*\}/);
            if (match) {
                try { return JSON.parse(match[0]); } catch {}
            }
            return null;
        }
    }

    escapeHtml(text) {
        return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    initMarkdown() {
        const check = setInterval(() => {
            if (window.marked) { this.markdownReady = true; clearInterval(check); }
        }, 100);
    }

    parseMarkdown(content) {
        if (!this.markdownReady) return `<pre>${this.escapeHtml(content)}</pre>`;
        try {
            return window.marked.parse(content
                .replace(/```(\w*)/g, '\n```$1\n')
                .replace(/```\s*$/g, '\n```\n')
                .replace(/\n{3,}/g, '\n\n'));
        } catch { return `<pre>${this.escapeHtml(content)}</pre>`; }
    }
}

try {
    new CoverageUI();
} catch (e) {
    console.error('[CoverageUI] init error:', e);
}
