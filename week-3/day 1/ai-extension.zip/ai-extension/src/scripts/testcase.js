import { getPrompt } from './prompts.js';

class TestCaseUI {
    constructor() {
        this.featureInput      = document.getElementById('tcFeature');
        this.domainInput       = document.getElementById('tcDomain');
        this.additionalInput   = document.getElementById('tcAdditional');
        this.generateButton    = document.getElementById('tcGenerate');
        this.resetButton       = document.getElementById('tcReset');
        this.messagesContainer = document.getElementById('tcMessages');
        this.copyButton       = document.getElementById('tcCopy');

        this.selectedModel    = '';
        this.selectedProvider = '';
        this.markdownReady    = false;

        this.initMarkdown();
        this.loadSettings();
        this.bindEvents();
    }

    // ─── Settings ────────────────────────────────────────────────────────────

    loadSettings() {
        chrome.storage.sync.get(
            ['groqApiKey', 'openaiApiKey', 'testleafApiKey', 'selectedModel', 'selectedProvider'],
            (result) => {
                if (result.groqApiKey)     this.groqAPI     = new GroqAPI(result.groqApiKey);
                if (result.openaiApiKey)   this.openaiAPI   = new OpenAIAPI(result.openaiApiKey);
                if (result.testleafApiKey) this.testleafAPI = new TestleafAPI(result.testleafApiKey);
                this.selectedModel    = result.selectedModel    || '';
                this.selectedProvider = result.selectedProvider || '';
            }
        );
        chrome.storage.onChanged.addListener((changes) => {
            if (changes.groqApiKey)       this.groqAPI     = new GroqAPI(changes.groqApiKey.newValue);
            if (changes.openaiApiKey)     this.openaiAPI   = new OpenAIAPI(changes.openaiApiKey.newValue);
            if (changes.testleafApiKey)   this.testleafAPI = new TestleafAPI(changes.testleafApiKey.newValue);
            if (changes.selectedModel)    this.selectedModel    = changes.selectedModel.newValue;
            if (changes.selectedProvider) this.selectedProvider = changes.selectedProvider.newValue;
        });
    }

    // ─── Events ──────────────────────────────────────────────────────────────

    bindEvents() {
        this.generateButton.addEventListener('click', () => this.generate());

        this.resetButton.addEventListener('click', () => {
            this.featureInput.value    = '';
            this.domainInput.value     = '';
            this.additionalInput.value = '';
            document.querySelectorAll('input[name="tcCoverage"]').forEach(cb => {
                cb.checked = cb.value === 'positive' || cb.value === 'negative';
            });
            this.messagesContainer.innerHTML = `
                <div class="initial-message">
                    <i class="fas fa-list-check"></i>
                    <span>Enter a <strong>feature</strong> and <strong>domain</strong> above, then click <strong>Generate Test Cases</strong>.</span>
                </div>`;
            window._tcState = null;
            this._lastContent = '';
            this.copyButton.style.display = 'none';
            document.dispatchEvent(new CustomEvent('tc:cleared'));
        });

        this.copyButton.addEventListener('click', () => this.copyResult());

        [this.featureInput, this.domainInput].forEach(el => {
            el.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') { e.preventDefault(); this.generate(); }
            });
        });
    }

    // ─── Core generate ───────────────────────────────────────────────────────

    async generate() {
        const feature    = this.featureInput.value.trim();
        const domain     = this.domainInput.value.trim();
        const additional = this.additionalInput.value.trim();

        if (!feature) {
            this.showMsg('Please enter a <strong>Feature</strong> before generating.');
            this.featureInput.focus();
            return;
        }
        if (!domain) {
            this.showMsg('Please enter a <strong>Domain</strong> before generating.');
            this.domainInput.focus();
            return;
        }

        const checked = Array.from(document.querySelectorAll('input[name="tcCoverage"]:checked'));
        if (checked.length === 0) {
            this.showMsg('Select at least one <strong>Test Coverage</strong> type.');
            return;
        }
        const coverage = checked.map(cb => cb.value).join(', ');

        const apiRef = this.resolveApi();
        if (!apiRef) {
            this.showMsg('No API key found. Go to the <strong>Settings</strong> tab to configure your provider.');
            return;
        }

        let prompt = getPrompt('TEST_CASE_GENERATOR', { feature, domain, coverage });
        if (additional) prompt += `\n\nAdditional Instructions:\n${additional}`;

        // Loading state
        this.generateButton.disabled = true;
        this.generateButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Generating…</span>';
        this.messagesContainer.innerHTML = `
            <div class="loading-indicator active">
                <div class="loading-spinner"></div>
                <span class="loading-text">Generating test cases for <em>${this.esc(feature)}</em>…</span>
            </div>`;

        try {
            const resp    = await apiRef.sendMessage(prompt, this.selectedModel);
            const content = (resp?.content || resp).trim();

            this.messagesContainer.innerHTML = '';
            this.renderResult(content, {
                inputTokens:  resp.usage?.input_tokens  || 0,
                outputTokens: resp.usage?.output_tokens || 0,
            });

            window._tcState = { feature, domain, coverage, content };
            this._lastContent = content;
            this.copyButton.style.display = 'inline-flex';
            this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
            document.dispatchEvent(new CustomEvent('tc:generated', { detail: window._tcState }));

        } catch (err) {
            this.messagesContainer.innerHTML = '';
            this.showMsg(`Error: ${this.esc(err.message)}`);
        } finally {
            this.generateButton.disabled = false;
            this.generateButton.innerHTML = '<i class="fas fa-list-check"></i><span>Generate Test Cases</span>';
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    copyResult() {
        const text = this._lastContent || '';
        if (!text) return;
        navigator.clipboard.writeText(text)
            .then(() => {
                this.copyButton.classList.add('copied');
                this.copyButton.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
                setTimeout(() => {
                    this.copyButton.classList.remove('copied');
                    this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
                }, 2000);
            })
            .catch(() => {
                this.copyButton.innerHTML = '<i class="fas fa-times"></i><span>Failed</span>';
                setTimeout(() => { this.copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>'; }, 2000);
            });
    }

    resolveApi() {
        if (this.selectedProvider === 'groq')   return this.groqAPI   || null;
        if (this.selectedProvider === 'openai') return this.openaiAPI || null;
        return this.testleafAPI || null;
    }

    // ─── Rendering ───────────────────────────────────────────────────────────

    renderResult(content, metadata) {
        const wrap = document.createElement('div');
        wrap.className = 'assistant-message';

        const md = document.createElement('div');
        md.className = 'markdown-content';
        md.innerHTML = this.parseMarkdown(content);
        wrap.appendChild(md);

        const bar = document.createElement('div');
        bar.className = 'message-actions';

        const copyBtn = document.createElement('button');
        copyBtn.type = 'button';
        copyBtn.className = 'btn-copy';
        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(content)
                .then(() => {
                    copyBtn.classList.add('copied');
                    copyBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                    setTimeout(() => {
                        copyBtn.classList.remove('copied');
                        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard';
                    }, 2000);
                })
                .catch(() => {
                    copyBtn.innerHTML = '<i class="fas fa-times"></i> Failed';
                    setTimeout(() => { copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy to Clipboard'; }, 2000);
                });
        });
        bar.appendChild(copyBtn);

        if (metadata.inputTokens || metadata.outputTokens) {
            const info = document.createElement('span');
            info.style.cssText = 'font-size:11px;color:var(--color-muted-text);margin-left:8px;';
            info.textContent = `${metadata.inputTokens} in / ${metadata.outputTokens} out tokens`;
            bar.appendChild(info);
        }

        wrap.appendChild(bar);
        this.messagesContainer.appendChild(wrap);
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }

    showMsg(html) {
        const div = document.createElement('div');
        div.className = 'chat-message system-message';
        div.innerHTML = html;
        this.messagesContainer.appendChild(div);
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }

    esc(t) {
        return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // ─── Markdown ────────────────────────────────────────────────────────────

    initMarkdown() {
        const iv = setInterval(() => {
            if (window.marked) { this.markdownReady = true; clearInterval(iv); }
        }, 100);
    }

    parseMarkdown(content) {
        if (!this.markdownReady) return `<pre>${this.esc(content)}</pre>`;
        try {
            return window.marked.parse(
                content.replace(/```(\w*)/g, '\n```$1\n')
                       .replace(/```\s*$/g, '\n```\n')
                       .replace(/\n{3,}/g, '\n\n')
            );
        } catch { return `<pre>${this.esc(content)}</pre>`; }
    }
}

// Module scripts are deferred — DOM is ready at this point
try {
    new TestCaseUI();
} catch (e) {
    console.error('[TestCaseUI] init error:', e);
}
